#ifndef BLACKJACK_H_INCLIDED
#define BLACKJACK_H_INCLIDED





void menu();
void jugarPartida();
void cargarPartidas();


#endif // BLACKJACK_H_INCLIDED